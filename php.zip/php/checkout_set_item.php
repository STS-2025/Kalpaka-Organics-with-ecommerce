<?php
/*
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
header('Content-Type: application/json');
require_once "db.php";

$_SESSION['checkout_source'] = 'temp';

// ✅ Check login
if (!isset($_SESSION['user_id'])) { 
    echo json_encode(["success"=>false,"step"=>"session","message"=>"Login required"]); 
    exit; 
}

$uid   = $_SESSION['user_id'];

$productId   = $_POST['product_id'] ?? 0;
$name  = $_POST['product_name'] ?? '';
$img   = $_POST['product_image'] ?? '';
$size  = $_POST['package_size'] ?? '';
$price = floatval($_POST['price'] ?? 0);
$qty   = max(1, intval($_POST['quantity'] ?? 1));

$response = [
    "success" => true,
    "steps" => []
];

// ✅ STEP 1: Delete old checkout items
$del = $conn->prepare("DELETE FROM checkout_items WHERE user_id = ?");
$del->bind_param("i", $uid);

if (!$del->execute()) {
    echo json_encode([
        "success" => false,
        "step" => "delete",
        "message" => "Delete failed",
        "errors" => $del->error
    ]);
    exit;
} else {
    $response["steps"][] = "Old checkout items deleted for user $uid";
}
$del->close();


// Step: Validate stock availability for the requested product and package size
$sql = "SELECT quantity AS available_stock FROM product_variants WHERE product_id = ? AND weight = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $productId, $size);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $available_stock = (int)$row['available_stock'];
    if ($qty > $available_stock) {
        echo json_encode([
            "success" => false,
            "step" => "stock_validation",
            "message" => "Requested quantity ($qty) exceeds available stock ($available_stock) for this product."
        ]);
        exit;
    }
} else {
    // No matching product variant found
    echo json_encode([
        "success" => false,
        "step" => "stock_validation",
        "message" => "Product variant not found."
    ]);
    exit;
}
$stmt->close();

// ✅ STEP 2: Insert new item
$sql = "INSERT INTO checkout_items (user_id, product_name, package_size, product_image, price, quantity) 
        VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("isssdi", $uid, $name, $size, $img, $price, $qty);

if (!$stmt->execute()) {
    echo json_encode([
        "success" => false,
        "step" => "insert",
        "message" => "Insert failed",
        "params" => [$uid, $name, $size, $img, $price, $qty],
        "errors" => $stmt->error
    ]);
    exit;
} else {
    $response["steps"][] = "New checkout item inserted";
    $response["params"]  = [$uid, $name, $size, $img, $price, $qty];
}
$stmt->close();

$conn->close();

// ✅ Final success response
echo json_encode($response);
?>
*/

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
header('Content-Type: application/json');
require_once "db.php";

$_SESSION['checkout_source'] = 'temp';

// ✅ Check login
if (!isset($_SESSION['user_id'])) { 
    echo json_encode(["success"=>false,"step"=>"session","message"=>"Login required"]); 
    exit; 
}

$uid = $_SESSION['user_id'];

// ✅ Trim relevant user inputs
$productId = intval($_POST['product_id'] ?? 0);
$name      = isset($_POST['product_name']) ? trim($_POST['product_name']) : '';
$img       = isset($_POST['product_image']) ? trim($_POST['product_image']) : '';
$size      = isset($_POST['package_size']) ? trim($_POST['package_size']) : '';
$price     = floatval($_POST['price'] ?? 0);
$qty       = max(1, intval($_POST['quantity'] ?? 1));

$response = [
    "success" => true,
    "steps" => []
];

// ✅ STEP 1: Delete old checkout items
$del = $conn->prepare("DELETE FROM checkout_items WHERE user_id = ?");
$del->bind_param("i", $uid);

if (!$del->execute()) {
    echo json_encode([
        "success" => false,
        "step" => "delete",
        "message" => "Delete failed",
        "errors" => $del->error
    ]);
    exit;
} else {
    $response["steps"][] = "Old checkout items deleted for user $uid";
}
$del->close();

// ✅ Step 2: Validate stock availability
$sql = "SELECT quantity AS available_stock FROM product_variants WHERE product_id = ? AND weight = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $productId, $size);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $available_stock = (int)$row['available_stock'];
    if ($qty > $available_stock) {
        echo json_encode([
            "success" => false,
            "step" => "stock_validation",
            "message" => "Requested quantity ($qty) exceeds available stock ($available_stock) for this product."
        ]);
        exit;
    }
} else {
    echo json_encode([
        "success" => false,
        "step" => "stock_validation",
        "message" => "Product variant not found."
    ]);
    exit;
}
$stmt->close();

// ✅ STEP 3: Insert new item
$sql = "INSERT INTO checkout_items (user_id, product_name, package_size, product_image, price, quantity) 
        VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("isssdi", $uid, $name, $size, $img, $price, $qty);

if (!$stmt->execute()) {
    echo json_encode([
        "success" => false,
        "step" => "insert",
        "message" => "Insert failed",
        "params" => [$uid, $name, $size, $img, $price, $qty],
        "errors" => $stmt->error
    ]);
    exit;
} else {
    $response["steps"][] = "New checkout item inserted";
    $response["params"]  = [$uid, $name, $size, $img, $price, $qty];
}
$stmt->close();

$conn->close();

// ✅ Final success response
echo json_encode($response);
?>
