<?php
/*session_start();
header('Content-Type: application/json');
require_once "db.php";

// ✅ Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "message" => "Login required"]);
    exit;
}


$uid   = $_SESSION['user_id'];
$full  = $_POST['full_name'] ?? '';
$phone = $_POST['phone'] ?? '';
$a1    = $_POST['address_line1'] ?? '';
$a2    = $_POST['address_line2'] ?? '';
$city  = $_POST['city'] ?? '';
$state = $_POST['state'] ?? '';
$pc    = $_POST['postal_code'] ?? '';
$isDef = isset($_POST['is_default']) ? 1 : 0;

// ✅ Phone validation
if (!preg_match('/^\+?\d{10,15}$/', $phone)) {
    echo json_encode(["success" => false, "message" => "Invalid phone number"]);
    exit;
}

// ✅ If this is default, reset previous defaults
if ($isDef) {
    $stmt = $conn->prepare("UPDATE addresses SET is_default = 0 WHERE user_id = ?");
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $stmt->close();
}

// ✅ Insert new address
$sql = "INSERT INTO addresses (user_id, full_name, phone, address_line1, address_line2, city, state, postal_code, is_default) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("isssssssi", $uid, $full, $phone, $a1, $a2, $city, $state, $pc, $isDef);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Address saved"]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to save: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
*/

session_start();
header('Content-Type: application/json');
require_once "db.php";

// ✅ Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "message" => "Login required"]);
    exit;
}

$uid   = $_SESSION['user_id'];
$full  = isset($_POST['full_name']) ? trim($_POST['full_name']) : '';
$phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';
$a1    = isset($_POST['address_line1']) ? trim($_POST['address_line1']) : '';
$a2    = isset($_POST['address_line2']) ? trim($_POST['address_line2']) : '';
$city  = isset($_POST['city']) ? trim($_POST['city']) : '';
$state = isset($_POST['state']) ? trim($_POST['state']) : '';
$pc    = isset($_POST['postal_code']) ? trim($_POST['postal_code']) : '';
$isDef = isset($_POST['is_default']) ? 1 : 0;

// ✅ Phone validation
if (!preg_match('/^\+?\d{10,15}$/', $phone)) {
    echo json_encode(["success" => false, "message" => "Invalid phone number"]);
    exit;
}

// ✅ If this is default, reset previous defaults
if ($isDef) {
    $stmt = $conn->prepare("UPDATE addresses SET is_default = 0 WHERE user_id = ?");
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $stmt->close();
}

// ✅ Insert new address
$sql = "INSERT INTO addresses (user_id, full_name, phone, address_line1, address_line2, city, state, postal_code, is_default) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("isssssssi", $uid, $full, $phone, $a1, $a2, $city, $state, $pc, $isDef);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Address saved"]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to save: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
