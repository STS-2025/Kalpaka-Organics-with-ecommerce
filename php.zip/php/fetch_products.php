<?php
// Database connection details
require_once "db.php";
// SQL query to fetch products and their minimum prices
$sql = "SELECT p.id, p.name, p.description, p.image, MIN(pv.price) as price
        FROM products p
        JOIN product_variants pv ON p.id = pv.product_id
        GROUP BY p.id
        ORDER BY p.id ASC";

$result = $conn->query($sql);
?>